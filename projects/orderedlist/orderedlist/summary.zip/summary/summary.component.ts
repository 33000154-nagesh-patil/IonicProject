import { CommonService } from 'projects/core/src/lib/services/common.service';
import { Component, OnInit,Input } from '@angular/core';
import { AllConfigDataService } from 'projects/core/src/lib/services/all-config-data.service';
import { ModalController } from '@ionic/angular';
import { SuccessDetailsComponent } from '../success-details/success-details.component';
import { LoaderService } from 'projects/core/src/lib/services/loader.service';
import { CommonFunctionService } from 'projects/core/src/lib/services/common-function.service';
import { AddressDetailsComponent } from '../address-details/address-details.component';
import { SelectAddComponent } from '../select-add/select-add.component';
import { ScheduleComponent } from '../schedule/schedule.component';
import { SelectPatientdetaiComponent } from '../select-patientdetai/select-patientdetai.component';
import { CartServiceService } from 'projects/core/src/lib/services/cart-service.service';
import { PatientDetailsComponent } from 'projects/orderedlist/patient-details/patient-details.component';
import { HttpHeaders, HttpClient } from '@angular/common/http';


declare var RazorpayCheckout:any;

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
})
export class SummaryComponent implements OnInit {
  imageList: any;
  currencySymbol: any;
  errorList: any;
  checkUseraddress: any;
  showQuantity:any;
  datas: any[];
  rupeesSymbol:any;
  getCurrency:any;
  InitialPrice:any = 0;

  userName:any;
  userAge:any;

@Input() data:any;
@Input() date:any;
@Input() fullName
@Input() age
@Input() gender
userGender: any;
  dataDetail: any;
  dataDetail2: any;
  dataDetail1: any;
  dataDetail3: any;
  dataDetail4: any;
  dataDetail5: any;


  constructor(private http: HttpClient, private allconfigDataService:AllConfigDataService,public modalController: ModalController,
    private CommonService:CommonService, private loaderService: LoaderService,private commonFunctionService:CommonFunctionService, private cartService: CartServiceService) { }


  async openAddressPage() {
    this.modalController.dismiss();
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: AddressDetailsComponent,
      componentProps: {
      },
      backdropDismiss: false
    });
    modal.onDidDismiss()
      .then((data) => {
        if (data && data?.data) {
          console.log("Save data");
          if (data) {
            this.checkUseraddress=data.data.value
          }
        }
      });
    this.loaderService.hideLoader();
    return await modal.present();
  }


  async addressTrue() {
   this.modalController.dismiss();
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: SelectAddComponent,
      componentProps: {
      },
      backdropDismiss: false
    });
    modal.onDidDismiss()
      .then((data) => {
        if (data && data?.data) {
          console.log("Save data");
          if (data) {

          //   this.CheckAddress=false
          //   this.checkUseraddress=data.data.value
          //   this.ifAddressAdded=false

           }
        }
      });
    this.loaderService.hideLoader();
    return await modal.present();
  }

  async detailTrue() {
   this.modalController.dismiss();
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: SelectPatientdetaiComponent,
      componentProps: {
      },
      backdropDismiss: false
    });
    modal.onDidDismiss()
      .then((data) => {
        if (data && data?.data) {
          console.log("Save data");

          if (data) {

          //   this.CheckAddress=false
          //   this.checkUseraddress=data.data.value
          //   this.ifAddressAdded=false

           }
           
        }
      });
    this.loaderService.hideLoader();
    return await modal.present();
  }

  async selectTime() {
    this.modalController.dismiss()

    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: ScheduleComponent,
      componentProps: {
      },
      backdropDismiss: false
    });
    modal.onDidDismiss()
      .then((data) => {
        if (data && data?.data) {
          console.log("Save data");
          if (data) {
          //   this.CheckAddress=false
          //   this.checkUseraddress=data.data.value
          //   this.ifAddressAdded=false
           }
        }
      });
    this.loaderService.hideLoader();
    return await modal.present();
  }


  



  payWithRazor1(amount,orderId) {
    var self:any = this;
    var options = {
      description: 'Credits towards consultation',
      image: 'https://cdn.zeplin.io/60a5fc059289442bc47e7527/assets/727E125B-F005-459F-AB50-9453AAC9134E.svg',//this.imageList?.companyLogo,
      order_id: '', //optional
      currency: "INR", // your 3 letter currency code
      key: "rzp_test_pBI3b5vibunYxn", // your Key Id from Razorpay dashboard
      amount: Number(Math.round(this.InitialPrice*100)), // Payment amount in smallest denomiation e.g. cents for USD
      name: 'Torus',
      prefill: {
        email: 'pankaj.gupta@heytrous.com', //optional
        contact: '7737879061', //optional
        name: 'pankaj received payment' //optional
      },
      theme: {
        color: '#003399'
      },
      modal: {
        ondismiss: function () {
          //alert('dismissed')
        }
      }
    };

    var successCallback = function (success: { razorpay_payment_id: any; razorpay_signature: any; }) {
      
      console.log("payment_id",success)
      if(success.razorpay_payment_id){
        self.getProductionTransactionPayment(success.razorpay_payment_id,success.razorpay_signature,"Success")
        
      }else{
        self.getProductionTransactionPayment('','',"Failed")
        self.errorShow('Payment Failed, Please Try Again',"payWithRazorpay -> successCallback");
      }

      //console.log('payment_id: ' + payment_id);
    };

    var cancelCallback = function (error: { description: any; }) {
      console.log("error",error)
      self.getProductionTransactionPayment('','',"Cancelled")
      self.errorShow(error.description,"payWithRazorpay -> cancelCallback");
    };

    // android
    
    RazorpayCheckout.on('payment.success', this.openSuccessPage())
    RazorpayCheckout.on('payment.cancel', cancelCallback)
    RazorpayCheckout.open(options);


//  Razorpay for web uncomment below line

  //   let rzp1=new this.CommonService.nativeWindow.Razorpay(options,this.openSuccessPage(),cancelCallback);
  //   rzp1.open();
  //   rzp1.on('payment.failed', function (response: any){
  //     console.log("fail",response);
  // })
  // rzp1.on('payment.success', function (response: any){
  //     console.log("success",response);
  // })



  }


    
  getPatientDetails() {
    let headers: HttpHeaders = new HttpHeaders({
      "Token": "MzNkYTg3ZGYtYzkwNS00OTk2LTllZmItMWI2ZTM4OGU1YTNi"
    });
    let params = {
      "custGuId":"7870892E-2074-441A-8FD6-0154B63217EE"
    }
    this.http.post("https://apixuat.heytorus.com/api/v1/Call/Shopping/Health/Lab/GetPatientDetails", params, { headers }).subscribe(async (res: any) => {
      // console.log("New product list data", res);


      console.log("--------------------------------->", res);
      // this.data = res[0]
      this.userName = res[0].first_Name;
      this.userAge = res[0].age;
      this.userGender = res[0].gender;

    }, (error: any) => {
      this.errorShow(error?.message, "productList --> Http request");
    }
    )
    
  }


   
  getAddressDetails() {
    let headers: HttpHeaders = new HttpHeaders({
      "Token": "MzNkYTg3ZGYtYzkwNS00OTk2LTllZmItMWI2ZTM4OGU1YTNi"
    });
    let params = {
      "CustGuId": "C83AD32B-F173-413E-9940-0C526F3560B7" 
    }
    this.http.post("https://apixuat.heytorus.com/api/v1/Call/Shopping/Health/Lab/GetPatientAddress", params, { headers }).subscribe(async (res: any) => {
      // console.log("New product list data", res);


      console.log("Address Detail--------------------------------->", res);

      this.dataDetail= res[0].addressLine1;
      this.dataDetail1= res[0].addressLine2;
      this.dataDetail2= res[0].pincode;
      console.log( this.dataDetail2);
      
      this.dataDetail3= res[0].city;
      this.dataDetail4= res[0].state;

      this.dataDetail5= res[0].country;



    

      // this.data = res[0]

    }, (error: any) => {
      this.errorShow(error?.message, "productList --> Http request");
    }
    )
    
  }

  
  openSuccessPage() {

    let successData = {
      'Title': "Order Placed Successfully",
      'Date': new Date(),
      'TransactionType': 'Done',
      'totalAmount': "",
      'quantity': '1',
      'rate': "1920",
      'transactionId': 'A-Hm-FH347-FGHK-347928',
    }
    this.openPaymentPopUp(successData)

  }
  errorShow(message: any, functionName: any) {
    this.loaderService.hideLoader();
    this.commonFunctionService.showErrorsService(this.errorList?.error, null, message, this.errorList?.okText);
  }


  async openPaymentPopUp(data) {
   this.modalController.dismiss()

    const modal = await this.modalController.create({
      component: SuccessDetailsComponent,
      componentProps: {
        // 'transactionData': data,
        // 'imageList': this.imageList,
        // 'currentCountry': "India",
        // 'errorList': this.errorList,
      },
      backdropDismiss: false
    });
    modal.onDidDismiss()
      .then((data) => {
        this.modalController.dismiss()
      });
    return await modal.present();
  }


  dismiss(){
    this.modalController.dismiss()
  }
 
 


  ngOnInit() {
    this.datas = this.cartService.getCartItems();
    this.getPatientDetails()
    this.getAddressDetails()
    this.totalPrice();
console.log("dataaaaaaaaaaaaaaaaaaaaaaaaaaa",this.datas.length);
console.log("dataaaaaaaaaaaaaaaaaaaaaaaaaaa",this.datas[1].product1[0].item_rate)

    this.dataForOrderSummary.currentDate=this.date
    this.dataForOrderSummary.time=this.data.selectedSlot
    this.imageList=this.allconfigDataService.getConfig('images')
    this.currencySymbol=this.allconfigDataService.getConfig('listCodeCountry')
    this.rupeesSymbol=this.getCurrency['IND']['currencySymbol'];

    // this.userName = this.fullName
    // console.log(this.userName);
    
    // this.userGender = this.gender
    // this.userAge = this.age

  
  }

  totalPrice(){
    if(this.datas.length == 1){
      this.InitialPrice += this.datas[0].product1[0].item_rate
      console.log(this.InitialPrice);
      
    }
    else{
      for(var i = 0; i < this.datas.length; i++){
        this.InitialPrice += this.datas[i].product1[0].item_rate  
        }
    }
    
    }


  dataForOrderSummary={
    medicineName:"Glucose - Fasting",
    provider:"Also known as Fasting Blood Sugar",
    provider1:"By Metropolis Healthcare Ltd. • Pathology Test",
    remove:"Remove",
    testNo:"1",
    quantity:"1",
    patientName:"Swapnil Vasant Joshi",
    age:"34",
    gender:"Male",
    address:"ICC Chambers, Saki Vihar Rd, Muranjan Wadi, Marol, Powai, Mumbai, Maharashtra, 400072",
    phoneNumber:"9967022045",
    price:"₹120.00",
    shippingCharge:"₹10.00",
    estimatedDate:"16 Mar 2022",
    total:"₹130.00",
    msg:"Yay! You've saved ₹50 on your shopping",
    userName:"Pratik Vasant Goswami",
    userAddress:"Shop No.1 to 05,Ground Floor, Kinjal Paradise, Plot No.43, Andheri west, Maharashtra 402010",
    userMobioleNo:"9810806463",
    currentDate:"16th March 2022",
    time:"13:00"  
    
  }  
}
