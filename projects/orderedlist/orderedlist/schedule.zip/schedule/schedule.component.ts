import { Component, OnInit,Input } from '@angular/core';
import { AllConfigDataService } from 'projects/core/src/lib/services/all-config-data.service';
import { ModalController } from '@ionic/angular';
import { LoaderService } from 'projects/core/src/lib/services/loader.service';
import { SummaryComponent } from '../summary/summary.component';
@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.scss'],
})
export class ScheduleComponent implements OnInit {

  imageList: any;
  isDatePicked:any=false
  active: any;
  pickedSlot:any
  @Input() selectTimeSlots:any
  constructor(private allconfigDataService:AllConfigDataService,public modalController: ModalController,private loaderService: LoaderService) { }

 
dateSelected(event ,status:any){
  if(status){
    this.isDatePicked=true
  }
  if(event.inputType==="deleteContentBackward"){
    this.isDatePicked=false
  }else{
    this.isDatePicked=true
  }
}

ToggleFun(e:any) {
  this.active=e
}

async openSummaryPage() {
  this.loaderService.showLoader();
  const modal = await this.modalController.create({
    component: SummaryComponent,
    componentProps: {
"data":this.active
    },
    backdropDismiss: false
  });
  modal.onDidDismiss()
    .then((data) => {
      if (data && data?.data) {
    
      }
    });
  this.loaderService.hideLoader();
  return await modal.present();
}

closeSelectPage(){
  this.modalController.dismiss()
}
  ngOnInit() {
    this.imageList=this.allconfigDataService.getConfig('images')

  }

}
