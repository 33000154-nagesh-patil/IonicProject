/*
 * Public API Surface of gold
 */

export * from './lib/gold.service';
export * from './lib/gold.component';
export * from './lib/gold.module';
