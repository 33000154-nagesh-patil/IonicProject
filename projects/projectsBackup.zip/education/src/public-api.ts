/*
 * Public API Surface of education
 */

export * from './lib/education.service';
export * from './lib/education.component';
export * from './lib/education.module';
