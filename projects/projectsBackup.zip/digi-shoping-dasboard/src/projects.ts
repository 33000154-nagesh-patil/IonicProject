/*
 * Public API Surface of digi-shoping-dasboard
 */

export * from './lib/digi-shoping-dasboard.service';
export * from './lib/digi-shoping-dasboard.component';
export * from './lib/digi-shoping-dasboard.module';
