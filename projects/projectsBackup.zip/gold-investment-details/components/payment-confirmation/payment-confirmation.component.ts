import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-payment-confirmation',
  templateUrl: './payment-confirmation.component.html',
  styleUrls: ['./payment-confirmation.component.scss'],
})
export class PaymentConfirmationComponent implements OnInit {
@Input() transactionData:any;
@Input() imageList:any;
@Input() currentCountry:any;
@Input() errorList:any;
  constructor(private modalCtrl:ModalController) { }

  ngOnInit() {}
  dismiss(){
    this.modalCtrl.dismiss()
  }

  trackOrder(){
    this.modalCtrl.dismiss('successful')
  }
}
