import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-investment-details',
  templateUrl: './investment-details.component.html',
  styleUrls: ['./investment-details.component.scss'],
})
export class InvestmentDetailsComponent implements OnInit {
@Input() currentDigiData:any;
@Input() currentCountry:any;
@Input() imageList:any;
@Input() currentInvestmentDetails:any;
@Input() goldSilverData:any;
@Output() sendToDetailPage = new EventEmitter();
step = 0;
  constructor() { }

  ngOnInit() {}
  setStep(index: number) {
    this.step = index;
  }
  redirectToDetails(){
    this.sendToDetailPage.emit('send')
  }
}
