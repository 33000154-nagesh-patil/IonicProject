import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-investment-details-transaction',
  templateUrl: './investment-details-transaction.component.html',
  styleUrls: ['./investment-details-transaction.component.scss'],
})
export class InvestmentDetailsTransactionComponent implements OnInit {

  @Input() imageList:any;
  @Input() currentCountry:any;
  @Input() errorList:any;
  @Input() investmentDetails:any;
  constructor(private modalCtrl:ModalController) { }

  ngOnInit() {}
  dismiss(){
    this.modalCtrl.dismiss()
  }
}
