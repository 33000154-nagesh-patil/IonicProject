import { Component, OnInit, Input } from '@angular/core';
import { ToastService } from 'projects/core/src/lib/services/toast.service';
import { ModalController } from '@ionic/angular';
@Component({
  selector: 'app-kyc-gold',
  templateUrl: './kyc-gold.component.html',
  styleUrls: ['./kyc-gold.component.scss'],
})
export class KycGoldComponent implements OnInit {
  _panCardKYCData: any;
  panCardKYCFlag:any;
  _bankKYCData: any;
  bankKYCFlag:any;
  _currentModuleType:any;
  get panCardKYC(): any {
    return this._panCardKYCData;
  }
  @Input() set panCardKYC(value: any) {
    // console.log("value",value)
    if(value && value.length > 0){
      this._panCardKYCData = value[0];
      this.panCardKYCFlag = value[0].IsCompleted
    }

  }
  get bankKYC(): any {
    return this._bankKYCData;
  }
  @Input() set bankKYC(value: any) {
    if(value && value.length > 0){
      this._bankKYCData = value[0];
      this.bankKYCFlag = value[0].IsCompleted
    }

  }
  get currentModuleType(): any {
    return this._currentModuleType;
  }
  @Input() set currentModuleType(value: any) {
    if(value){
      this._currentModuleType = value;
    }

  }
@Input() imageList:any
@Input() errorList:any;
@Input() name:any;
@Input() loginCustomerGuId:any;
showSuccessMessage:any=false;
  constructor(private toastService:ToastService,private modalController:ModalController) { }

  ngOnInit() {}
  currentPANStatus(e){
    if(e){
      this.panCardKYCFlag = true;
    }
  }
  currentBankStatus(e){
    if(e){
      this.bankKYCFlag = true
      this.showSuccessMessage = true;
    }
  }

  sendToGold(){
    this.modalController.dismiss({data:'done'})
  }

  panName(e){
    this.name = e;
  }

}
