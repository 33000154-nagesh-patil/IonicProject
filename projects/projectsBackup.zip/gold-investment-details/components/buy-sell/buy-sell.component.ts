import { Component, OnInit, Input, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ToastService } from 'projects/core/src/lib/services/toast.service';
import { CommonService } from 'projects/core/src/lib/services/common.service'
import { CommonFunctionService } from 'projects/core/src/lib/services/common-function.service';
import { LoaderService } from 'projects/core/src/lib/services/loader.service';
import { urlFetch } from 'projects/core/src/lib/enums/comman.enum';
declare var RazorpayCheckout:any;
@Component({
  selector: 'app-buy-sell',
  templateUrl: './buy-sell.component.html',
  styleUrls: ['./buy-sell.component.scss'],
})
export class BuySellComponent implements OnInit {
  _type:any;
  showGramsError:any = false;
  currentTypeOrder:any;
  _currentData:any;
  @Input() imageList:any;
  @Input() currentCountry:any;
  @Input() errorList:any;
  @Input() listIdData:any;
  @Input() paymentWay:any;
  currentUserGoldGrams:any='0.18';
  ProductWeight:any;
  productAmount:any;
  currentGoldProductTransaction:any;
  get currentData(): any {
    return this._currentData;
  }
  @Input() set currentData(value: any) {
    // console.log("_currentData",value)
    this._currentData = value;
    this.ProductWeight = value?.Props?.ProductWeight;
    this.currentAmount = ((value?.Price['0']?.Buy || value?.Price?.Buy) * Number(value?.Props?.ProductWeight)) * 1.03;
    // console.log("this.currentAmount",this.currentAmount)
  }
  get type(): any {
    return this._type;
  }
  @Input() set type(value: any) {
    // console.log("value",value)
    this._type = value;
   if(this._type == 'buy'){
    this.currentTypeOrder = "amount";
   }
   if(this._type == 'sell'){
    this.currentTypeOrder = "grams";
   }

  }

  showError:any = false;
  currentAmount:any;
  policyCheckBox:any=true;

  loginCustomerGuId: any;
  currentProductTransaction: any;

  @ViewChild('commaInput') commaInput: ElementRef;
  public listener: () => void;
  constructor(private toastService:ToastService,private modalCtrl:ModalController,private renderer: Renderer2,private commonService:CommonService,private commonFunctionService:CommonFunctionService,private loaderService:LoaderService) { }

  ngOnInit() {}

  dismissInvest(){
    this.modalCtrl.dismiss()
  }
  public onQtrInputChange(event: any) {
    this.showError = false;
    // console.log(event);
    if (event.replace(/\D/g, '') === '') {
      this.currentAmount = 0;
    } else {
      this.currentAmount = Number(event.replace(/\D/g, ''));
    }
  }

  public onFocusCommaInput() {
    this.showError = false;
    // ############### LISTENER ON ###############
    this.listener = this.renderer.listen('window', 'keyup', event => {
      this.commaInput.nativeElement.value = this.commaInput.nativeElement.value.replace(/[^\d,]/g, '');
    });
    // console.log('Listening...');
  }

  public onBlurCommaInput() {
    this.showError = false;
    // ############### LISTENER OFF ###############
    this.listener();
    // console.log('Quiet...');
  }

  checkboxClick(e){
    this.policyCheckBox = !this.policyCheckBox
  }
  segmentChanged(e){
    if(this.paymentWay == 'nondirect'){
      // console.log(e)
      this.currentTypeOrder = e.detail.value
      this.currentAmount = 0;
    }

  }

  setAmount(e){
    this.onQtrInputChange(e)
   }
  setGrams(e){
    this.currentAmount = Number(e)
  }
   submitInvest(){
    if(this.policyCheckBox){
      this.checkValidationAmount()
    }else{
      this.toastService.showAutoToast(this.errorList?.tcError)
    }
  }
  checkValidationAmount(){
    if(this.currentAmount > 0){
      //this.checkKYCStatus()
      //this.dismiss();
      if(this.currentTypeOrder == 'grams'){
        this.productAmount = (this.currentAmount * this._currentData?.Price[0]?.Buy)*1.03;
        this.ProductWeight = this.currentAmount;
      }else{
        this.productAmount = this.currentAmount
        this.ProductWeight = (this.currentAmount - 0.3*this.currentAmount) / this._currentData?.Price[0]?.Buy
      }
      let localProductionTransaction ={
        "CustGuId":this.listIdData?.CustGuId,
        "OfferingGuId":this.listIdData?.currentModuleData?.OfferingGuId,
        "ProductName":this._currentData?.Title,
        "ProductId":this._currentData?.CategoryId,
        "Units":this._currentData?.Props?.ProductWeight,
        "MetalType":this.listIdData?.currentModuleData?.Offering,
        "Amount":this._currentData?.Price[0]?.Buy*this._currentData?.Props?.ProductWeight,
        "BlockId":this._currentData?.Props?.BlockId,
        "CGSST":this._currentData?.Props?.Taxes[0]?.taxPerc,
        "SGST":this._currentData?.Props?.Taxes[1]?.taxPerc,
        "Transaction":this._type,
        "PricePerGram":this._currentData?.Price[0]?.Buy,
        "Purity":'24K'
      }
      if(localProductionTransaction){
        // this.payWithRazorpay(this.currentAmount)
      this.callProductionTransaction(localProductionTransaction)
      }

    }else{
      this.showError = true;
    }
  }
  dismiss(data){
    // let investData = {
    //   'currentAmount':this.currentAmount,
    //   'currentData':this.currentData
    // }
    if(data){
      // console.log("investData",data)
      this.modalCtrl.dismiss(data);
    }

  }
  keyPressNumbersWithDecimal(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57)) {
      event.preventDefault();
      return false;
    }
    return true;
  }
  setCurrentGramValue(e){
    this.currentAmount = Number(e)
  }
  sellInvest(){
    this.showGramsError = false;
    this.showError = false;
    if(!this.currentAmount){
      this.showError = true;
    }else{
      if(this.currentAmount > Number(this.currentUserGoldGrams)){
        // console.log("if")
        this.showGramsError = true

      }else{
        // console.log("else")
      }
    }

  }

  payWithRazorpay(amount,orderId) {
    var self:any = this;
    var options = {
      description: 'Credits towards consultation',
      image: 'https://cdn.zeplin.io/60a5fc059289442bc47e7527/assets/727E125B-F005-459F-AB50-9453AAC9134E.svg',//this.imageList?.companyLogo,
      order_id: '', //optional
      currency: "INR", // your 3 letter currency code
      key: "rzp_test_pBI3b5vibunYxn", // your Key Id from Razorpay dashboard
      amount: Number(Math.round(amount*100)), // Payment amount in smallest denomiation e.g. cents for USD
      name: 'Aqube',
      prefill: {
        email: 'test@razorpay.com', //optional
        contact: '9990009991', //optional
        name: 'Razorpay' //optional
      },
      theme: {
        color: '#003399'
      },
      modal: {
        ondismiss: function () {
          //alert('dismissed')
        }
      }
    };

    var successCallback = function (success) {
      // console.log("payment_id",success)
      if(success.razorpay_payment_id){
        self.getProductionTransactionPayment(success.razorpay_payment_id,success.razorpay_signature,"Success")

      }else{
        self.getProductionTransactionPayment('','',"Failed")
        self.errorShow('Payment Failed, Please Try Again',"payWithRazorpay -> successCallback");
      }

      //console.log('payment_id: ' + payment_id);
    };

    var cancelCallback = function (error) {
      console.log("error",error)
      self.getProductionTransactionPayment('','',"Cancelled")
      self.errorShow(error.description,"payWithRazorpay -> cancelCallback");
    };

    RazorpayCheckout.on('payment.success', successCallback)
    RazorpayCheckout.on('payment.cancel', cancelCallback)
    RazorpayCheckout.open(options);

  }

  callProductionTransaction(obj){
    this.fetchProductionTransaction(obj)
  }

  getProductionTransactionPayment(payment_id,signature,status){
    let localProductionTransactionPaymentResponse ={
      "TorusTranGuId":this.currentGoldProductTransaction?.TorusTranGuId,
      "OrderGuId":this.currentGoldProductTransaction?.OrderGuId,
      "PaymentId":payment_id,
      "Razorpay_Signature":signature,
      "CustGuId":this.currentGoldProductTransaction?.CustGuId,
      "OfferingGuId":this.currentGoldProductTransaction?.OfferingGuId,
      "Transaction":this._type,
      "Units":this._currentData?.Props?.ProductWeight,
      "Amount":this._currentData?.Price[0]?.Buy,
      "BlockId":this._currentData?.Props?.BlockId,
      "MetalType":this.listIdData?.currentModuleData?.Offering,
      "orderStatus":status,
      "ModeOfPayment":"NEFT"
    }
    if(localProductionTransactionPaymentResponse){
      this.fetchProductionTransactionPayment(localProductionTransactionPaymentResponse)
    }
  }
  fetchProductionTransaction(obj){
    this.loaderService.showLoader()
    this.commonService.getGoldProductTransaction(obj).subscribe((data:any)=>{
      if(data && data.Status){
        this.loaderService.hideLoader()
        this.currentGoldProductTransaction = data;
        this.payWithRazorpay(this.productAmount,data?.OrderGuId);


      }else{
        this.errorShow("Buy GoldSilver","fetchProductionTransaction -> data status")
      }
    },
    (error:any)=>{
     this.errorShow(error,"fetchProductionTransaction -> Http response")
    }
    )
  }

  fetchProductionTransactionPayment(obj){
    //this.loaderService.showLoader()
    this.commonService.getGoldPaymentProductTransaction(obj).subscribe((data:any)=>{
      if(data && data.Status){
        //this.loaderService.hideLoader()
        if(obj.orderStatus == 'Success'){
          let response = {
            'Title':this._currentData?.Title,
            'Date':new Date(),
            'TransactionType':'Buy',
            'totalAmount':data.resultGS?.totalAmount,
            'quantity':data.resultGS?.quantity,
            'rate':data.resultGS?.rate,
            'transactionId':data.resultGS?.transactionId
          }
          this.dismiss(response);
        }

      }else{
        this.errorShow("Buy GoldSilver","fetchProductionTransactionPayment -> data status")
      }
    },
    (error:any)=>{
     this.errorShow(error,"fetchProductionTransactionPayment -> Http response")
    })
  }

  errorShow(message, functionName){
    this.loaderService.hideLoader();
    this.commonFunctionService.showErrorsService(this.errorList?.error,'gold buy/sell page -> '+functionName,message,this.errorList?.okText);
  }

  clickDisclaimerURL() {
    this.commonFunctionService.inAppBrowser(urlFetch.disclaimerURL);
  }
  clickTncUrl() {
    this.commonFunctionService.inAppBrowser(urlFetch.tncURL);
  }
}
