import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { IonicModule } from '@ionic/angular';
import { currencyCommasModule } from 'projects/core/src/lib/pipe/currency-commas.module';
import { TranslateModule } from 'projects/core/src/lib/pipe/translate.module';
import { InvestmentDetailsComponent } from 'projects/gold-investment-details/components/investment-details/investment-details.component';
import { OrderDetailsComponent } from 'projects/gold-investment-details/components/order-details/order-details.component';
import { BuySellComponent } from 'projects/gold-investment-details/components/buy-sell/buy-sell.component';
import { GoldInvestmentDetailsComponent } from './gold-investment-details.component';
import { CoreModule } from 'projects/core/src/public-api';
import { KycGoldComponent } from 'projects/gold-investment-details/components/kyc-gold/kyc-gold.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { PaymentConfirmationComponent } from 'projects/gold-investment-details/components/payment-confirmation/payment-confirmation.component';
import { OrdersComponent } from 'projects/gold-investment-details/components/orders/orders.component';
import { MatExpansionModule } from '@angular/material/expansion'; 
import { InvestmentDetailsTransactionComponent } from 'projects/gold-investment-details/components/investment-details-transaction/investment-details-transaction.component';
@NgModule({
  declarations: [GoldInvestmentDetailsComponent,InvestmentDetailsComponent,OrderDetailsComponent,BuySellComponent,KycGoldComponent,PaymentConfirmationComponent,OrdersComponent,InvestmentDetailsTransactionComponent],
  imports: [IonicModule,CommonModule,TranslateModule,currencyCommasModule,CoreModule,FormsModule,ReactiveFormsModule,MatInputModule,MatFormFieldModule,MatExpansionModule
  ],
  exports:[GoldInvestmentDetailsComponent,InvestmentDetailsComponent,OrderDetailsComponent,BuySellComponent,KycGoldComponent,OrdersComponent,InvestmentDetailsTransactionComponent]
})
export class GoldInvestmentDetailsModule { }
