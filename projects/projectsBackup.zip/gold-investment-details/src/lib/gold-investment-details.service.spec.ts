import { TestBed } from '@angular/core/testing';

import { GoldInvestmentDetailsService } from './gold-investment-details.service';

describe('GoldInvestmentDetailsService', () => {
  let service: GoldInvestmentDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GoldInvestmentDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
