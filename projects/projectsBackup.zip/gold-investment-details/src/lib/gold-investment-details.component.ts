import { Component, Input, OnInit } from '@angular/core';
import { CommonService } from 'projects/core/src/lib/services/common.service';
import { ModalController } from '@ionic/angular';
import { LoaderService } from 'projects/core/src/lib/services/loader.service';
import { KycGoldComponent } from 'projects/gold-investment-details/components/kyc-gold/kyc-gold.component';
import { BuySellComponent } from 'projects/gold-investment-details/components/buy-sell/buy-sell.component';
import { PaymentConfirmationComponent } from 'projects/gold-investment-details/components/payment-confirmation/payment-confirmation.component';
import { InvestmentDetailsTransactionComponent } from 'projects/gold-investment-details/components/investment-details-transaction/investment-details-transaction.component';
@Component({
  selector: 'lib-goldInvestmentDetails',
  templateUrl: './gold-investment-details.component.html',
  styleUrls: ['./gold-investment-details.component.scss'],
})
export class GoldInvestmentDetailsComponent implements OnInit {
  _currentUserGoldData:any;
  _currentUserSilverData:any;
@Input() errorList:any;
@Input() currentDigiType:any;
@Input() imageList:any;
@Input() currentDigiData:any;
@Input() currentProductDatalib:any;
@Input() currentCountry:any;
@Input() currentDigiDataOrderList:any;
@Input() goldSilverData:any;

get currentUserGoldData(): any {
  return this._currentUserGoldData;
}
@Input() set currentUserGoldData(value: any) {
  // console.log("_currentUserGoldData",value)
  this._currentUserGoldData = value;
}
get currentUserSilverData(): any {
  return this._currentUserSilverData;
}
@Input() set currentUserSilverData(value: any) {
  // console.log("_currentUserGoldData",value)
  this._currentUserSilverData = value;
}
getCurrentDigiType:any;
currentFetcherModule:any;
listOfKYC:any;
isKYCCompleted:any = false;
loginCustomerGuId:any;
currentInvestmentDetails:any;
showModal:any = false;
  constructor(private commonService:CommonService,public modalController: ModalController,private loaderService:LoaderService) { }

  ngOnInit() {
    // console.log("currentDigiData",this.currentDigiData)
    // console.log("goldSilverData",this.goldSilverData)
    this.commonService.getDigiType().subscribe((data:any)=>{
      this.getCurrentDigiType = data;
      this.getOfferingId(data);
    })


    this.loginCustomerGuId = localStorage.getItem('CustGuId')
    if(!this.loginCustomerGuId){
      this.commonService.getCustomerGuID().subscribe((data:any)=>{
        if(data){
          this.loginCustomerGuId = data;
        }
      })
    }
    if(this.goldSilverData){
    this.goldSilverData = this.goldSilverData.filter(x=>x.type==this.currentDigiType)
    }
  }
  getOfferingId(type){
    // console.log("type",type)
    this.commonService.getOfferListData().subscribe((data:any)=>{
      // console.log("getFetchParentModule",data)
      if(data && data?.OfferList && data?.OfferList.length > 0){
        let localCurrentModule = data.OfferList.filter(x => x?.Offering == type);
        if(localCurrentModule && localCurrentModule.length >0){
          // console.log("localCurrentModule",localCurrentModule)
          this.currentFetcherModule = localCurrentModule[0]
        }

      }
    })
    this.commonService.getGetOfferingDocList().subscribe((data:any)=>{
      // console.log("getGetOfferingDocList",data)
      if(data && data?.length > 0){

        this.listOfKYC = data;
        let localKYCObject = this.listOfKYC.filter(x =>(x?.Offering == type && x?.IsCompleted == 'False'));
        if(localKYCObject && localKYCObject.length == 0){
          this.isKYCCompleted = true
        }
      }
    })
  }
  openModal(){
    this.showModal = !this.showModal;
    // console.log("this.showModal",this.showModal)
  }
  investGold(){
    // console.log("iskyc")
    if(this.isKYCCompleted){
      this.openOrderPopup();
    }else{
      this.openKYCModal();
    }
    //this.openPaymentPopUp({ 'currentAmount':'1000','currentData':{'Title':'AugMont Digital Gold','Date':new Date(),'Units':'0.21','TotalPrice':'4632','TransactionType':'Buy','TransactionID':'A-hm-Fh-347892','GSTPrice':'3'}})
  }

  async openOrderPopup(){
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: BuySellComponent,
      componentProps: {
        'currentData':this.currentProductDatalib?.productDetails,
        'imageList':this.imageList,
        'currentCountry':this.currentCountry,
        'errorList':this.errorList,
        'type':'buy',
        'paymentWay':'nondirect',
        "listIdData":{'CustGuId':this.loginCustomerGuId,'currentModuleData':this.currentFetcherModule}
      },
      backdropDismiss:false
    });
    modal.onDidDismiss()
    .then((data) => {
      if(data && data?.data){
        this.openPaymentPopUp(data?.data)
      }
    });
    this.loaderService.hideLoader();
    return await modal.present();
  }

  async openKYCModal(){
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: KycGoldComponent,
      componentProps: {
        'panCardKYC':this.getCurrentKYCData("PAN"),
        'bankKYC':this.getCurrentKYCData("Cheque"),
        'imageList':this.imageList,
        'errorList':this.errorList,
        'currentModuleType':this.currentFetcherModule,
        'loginCustomerGuId':this.loginCustomerGuId
      },
      backdropDismiss:false
    });
    modal.onDidDismiss()
    .then((data) => {
      if(data && data?.data){
        this.openOrderPopup();
      }
    });
    this.loaderService.hideLoader();
    return await modal.present();
  }
  async openPaymentPopUp(data){
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: PaymentConfirmationComponent,
      componentProps: {
        'transactionData':data,
        'imageList':this.imageList,
        'currentCountry':this.currentCountry,
        'errorList':this.errorList,
      },
      backdropDismiss:false
    });
    modal.onDidDismiss()
    .then((data) => {
      if(data && data?.data){
        // console.log("openOrderList")
        this.openOrderList();
      }
    });
    this.loaderService.hideLoader();
    return await modal.present();
  }
  async openOrderList(){
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: InvestmentDetailsTransactionComponent,
      componentProps: {
        'imageList':this.imageList,
        'currentCountry':this.currentCountry,
        'errorList':this.errorList,
        "investmentDetails":this.getCurrentDigiType == "Gold"?this._currentUserGoldData:this.getCurrentDigiType == "Silver"?this._currentUserSilverData:''
      },
      backdropDismiss:false
    });
    modal.onDidDismiss()
    .then((data) => {
      if(data && data?.data){
      }
    });
    this.loaderService.hideLoader();
    return await modal.present();
  }
  getCurrentKYCData(type){
    return this.listOfKYC?this.listOfKYC.filter(x => x?.Document == type):[]
  }
  redirectToPage(e){
    this.openDetailPage()
  }

  async openDetailPage(){
    this.loaderService.showLoader();
    const modal = await this.modalController.create({
      component: InvestmentDetailsTransactionComponent,
      componentProps: {
        'imageList':this.imageList,
        'currentCountry':this.currentCountry,
        'errorList':this.errorList,
        "investmentDetails":this.getCurrentDigiType == "Gold"?this._currentUserGoldData:this.getCurrentDigiType == "Silver"?this._currentUserSilverData:''
      },
      backdropDismiss:false
    });
    modal.onDidDismiss()
    .then((data) => {
      if(data && data?.data){
      }
    });
    this.loaderService.hideLoader();
    return await modal.present();
  }
}
