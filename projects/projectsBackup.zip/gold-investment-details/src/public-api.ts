/*
 * Public API Surface of gold-investment-details
 */

export * from './lib/gold-investment-details.service';
export * from './lib/gold-investment-details.component';
export * from './lib/gold-investment-details.module';
