/*
 * Public API Surface of digi-profile
 */

export * from './lib/digi-profile.service';
export * from './lib/digi-profile.component';
export * from './lib/digi-profile.module';
