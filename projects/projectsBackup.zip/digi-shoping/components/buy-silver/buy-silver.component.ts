import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-buy-silver',
  templateUrl: './buy-silver.component.html',
  styleUrls: ['./buy-silver.component.scss'],
})
export class BuySilverComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
