import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-sell-silver',
  templateUrl: './sell-silver.component.html',
  styleUrls: ['./sell-silver.component.scss'],
})
export class SellSilverComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
