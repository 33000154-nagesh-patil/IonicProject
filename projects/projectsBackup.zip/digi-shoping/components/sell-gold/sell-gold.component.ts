import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-sell-gold',
  templateUrl: './sell-gold.component.html',
  styleUrls: ['./sell-gold.component.scss'],
})
export class SellGoldComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
