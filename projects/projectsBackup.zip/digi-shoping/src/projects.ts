/*
 * Public API Surface of digi-shoping
 */

export * from './lib/digi-shoping.service';
export * from './lib/digi-shoping.component';
export * from './lib/digi-shoping.module';
