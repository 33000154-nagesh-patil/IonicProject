/*
 * Public API Surface of health-lab-test-dashboard
 */

export * from './lib/health-lab-test-dashboard.service';
export * from './lib/health-lab-test-dashboard.component';
export * from './lib/health-lab-test-dashboard.module';
