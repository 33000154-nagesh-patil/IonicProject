/*
 * Public API Surface of lib-config
 */

export * from './lib/lib-config.service';
export * from './lib/lib-config.component';
export * from './lib/lib-config.module';
