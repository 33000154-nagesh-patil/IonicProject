import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { AllConfigDataService } from 'index';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.scss'],
})
export class ListingComponent implements OnInit {

  imageList = this.allConfigDataService.getConfig("images");
  apiCatalog = this.allConfigDataService.getConfig("apiCatalog");
  appEnvironment = this.allConfigDataService.getConfig("environmentType");
  filterIcon = false;
  cartCount
  notificationCount
  @Input() gridList: boolean = false;
  @Input() cardList: boolean = true;
  @Input() dataList: any;
  @Input() DummayTitle: any;
  @Input() product: any;
  Data: any;
  // @Input() heading

  constructor(
    private allConfigDataService: AllConfigDataService,
    private http: HttpClient,
    private router: Router

  ) { }

  // ionViewDidEnter() {
  //   let params = {
  //     "PageNo": 1,
  //     "nRows": 5
  //   }
  //   this.http.post(
  //     this.apiCatalog.baseURL[this.appEnvironment] + "Shopping/Career/Courses" + this.apiCatalog.getList, params
  //   )
  //     .subscribe((data: any) => {
  //       // this.dataList = data.data;
  //     })

  //   this.DummayTitle = [
  //     {
  //       "name": "Top Rated Fund",
  //       "icon": "assets/icon/group1.svg",
  //     },
  //     {
  //       "name": "Tax Savers",
  //       "icon": "assets/icon/group2.svg",

  //     },
  //     {
  //       "name": "New Fund Offers",
  //       "icon": "assets/icon/group3.svg",

  //     },
  //     {
  //       "name": "Annual Return Fund",
  //       "icon": "assets/education/Group1.svg",

  //     },
  //     {
  //       "name": "Wealth Builder",
  //       "icon": "assets/education/Group2.svg",

  //     },
  //     {
  //       "name": "Steady Income",
  //       "icon": "assets/education/Group3.svg",
  //     },
  //   ]
  // }

  ngOnInit() {
    if (this.router.url == '/Shopping/Wealth/MutualFunds/Listing') {
      this.http.get("assets/listing/mutualfundList.json").subscribe((data) => {
          this.Data = data
        })
    }
    else if (this.router.url == '/Shopping/Wealth/Gold/Listing'){
      this.http.get("assets/listing/dgList.json").subscribe((data) => {
          this.Data = data
        })
    }
    else if (this.router.url == '/Shopping/Career/Listing'){
      this.http.get("assets/listing/educationCoursesList.json").subscribe((data) => {
          this.Data = data
        })
    }
    else if (this.router.url == '/Shopping/Health/Listing'){
      this.http.get("assets/listing/healthList.json").subscribe((data) => {
          this.Data = data
        })
    }
  }

}
